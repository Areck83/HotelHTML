| Omologo 1.01                             |
|                                          |
| Bellini Studio                           |
| bellinistudio.eu                         |
| infobellinistudio@gmail.com              |
| https://www.facebook.com/bellinistudioeu |

  Thanks for download a free* version of 'Omologo', a brand new Serif Semi Stencil font family based on "old style" typography, translated in modern era with Unconventional number of LIGATURE. A mix of geometric forms, antique ligature and oblsolete (or forget?) gliphs.

Currently it comes in 2 styles: round and italic.

Each weight includes extended language support, ligatures and up to 640 gliph (2000 gliphs in the complete version).

Opentype feature Free Version

    Standard ligature (liga)
    Lining + Oldstyle figure linear or tabular (lnum, onum)
    Numerator + Denominator + Subscript + Superscript (pnum, tnum, sups, subs)
    Fraction (frac)
    Kerning table (kern)

Opentype feature Pro Version

    Discretionary ligature (dlig)
    Alternative style set (ss01, ss02)
    Small capital (c2sc, smcp)


Unicode block supported in Free & Pro version

    C0 Controls and Basic Latin
    C1 Controls and Latin-1 Supplement
    Latin Extended-A
    Latin Extended-B

Omologo is incredibly useful on most of creative field like magazine, poster, book, composition and it's a great ingredient to have in every kitchen!

Good work at all - Bellini Studio

    http://www.bellinistudio.eu
    https://www.facebook.com/bellinistudioeu/
    https://www.behance.net/gallery/64540463/Omologo-Serif-Semi-Stencil

  
BUY it on
    Creative Fabrica - https://www.creativefabrica.com/product/omologo/
    Creative Market - https://creativemarket.com/saviobellini/2469318-Omologo-Serif-Semi-Stencil-font


-----------------------------------------------------
NOTE: 
  This is a free* version  of 'Omologo' family font.
  <*for personal use - non commercial>

    
  If you like, share or try a complete version.
  
  Good work at all - Bellini Studio